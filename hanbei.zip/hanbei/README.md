### I'm FADHIL GRAPHY Gift Me Stars 🌟 <br><img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="20px">
<p align="center">
<a href="https://github.com/FdhlGraphy"><img src="https://raw.githubusercontent.com/FdhlGraphy/FdhlGraphy/main/banner.jpg"></a>
</p>
<br>


<p align="center">
<a href="#"><img title="botwa-termux" src="https://img.shields.io/badge/-BOTWA--TERMUX-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/FdhlGraphy"><img title="Author" src="https://img.shields.io/badge/AUTHOR-FADHIL-orange?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/FdhlGraphy/botwa-termux/followers"><img title="Followers" src="https://img.shields.io/github/followers/FdhlGraphy?style=flat-square"></a>
<a href="https://github.com/FdhlGraphy/botwa-termux/network/members"><img title="Forks" src="https://img.shields.io/github/forks/FdhlGraphy/botwa-termux?style=flat-square"></a>
<a href="https://github.com/FdhlGraphy/botwa-termux/watchers"><img title="watchers" src="https://img.shields.io/github/watchers/FdhlGraphy/botwa-termux?style=flat-square"></a>

</p>

### Made By

<p align="center">
    <a href="https://github.com/NazwaS"><img title="Paritsod" src="https://avatars.githubusercontent.com/u/75057738?s=460&u=c7d37d13fdb8977a4474bf743a87a7f39c00dc4b&v=4" width="128"></a>
    <a href="https://github.com/Fxc7"><img title="Paritsod" src="https://avatars.githubusercontent.com/u/74123134?s=460&u=b46fc7480075ccc529e483a1d9522659a98666d4&v=4" width="128"></a>
    <a href="https://github.com/FdhlGraphy"><img title="Paritsod" src="https://avatars.githubusercontent.com/u/75799657?s=460&u=f5074ff04c8472c59ad2670c0d25b06bc5e9c6f3&v=4" width="128"></a>
</p>

## SOSMED

<p align="center">
 <a href="https://instagram.com/ahmd.fdhl_"><img alt="Instagram" src="https://img.shields.io/badge/Instagram-AB34B6?style=for-the-badge&logo=instagram&logoColor=white"/></a>
 <a href="https://youtube.com/c/FadhilGraphy"><img alt="YouTube" src="https://img.shields.io/badge/YouTube-FE0000?style=for-the-badge&logo=youtube&logoColor=white"/></a>
 <a href="https://wa.me/6288221608614"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>
</p>


## GROUP

* <a href="https://chat.whatsapp.com/JANODO6ODi65fFQ22V4ac8"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp%20Group%201-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>
* <a href="https://chat.whatsapp.com/I4AqcaILXHj3jrJ3MVURkc"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp%20Group%202-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>
* <a href="https://t.me/joinchat/FT_-G7e136-CWXTM"><img alt="Telegram" src="https://img.shields.io/badge/Telegram%20Group-30ACE0?style=for-the-badge&logo=telegram&logoColor=white"/></a>

---

## Tools and Materials

```bash
> Niat
> Termux
> WhatsApp
> 2 HandPhone
```

## Install For Termux
Follow The Steps Below!

```bash
> termux-setup-storage
> pkg update -y
> pkg upgrade -y
> pkg install git -y
> git clone https://github.com/FdhlGraphy/botwa-termux
> cd botwa-termux
> bash install.sh
```

### RUN BOT

```bash
> npm start
```

### STOP THE BOT

```bash
> ctrl + z
```
Can Also Use

```bash
> ctrl + c
```

### Editing Options
Open In Setting.json!

```bash
{
    "prefix": "#",
    "instagram": "https://www.instagram.com/ahmd.fdhl_",
    "yt": "https://youtubemcom/FadhilGraphy",
    "name": "FADHIL BOT",
    "replySet": "SUBSCRIBE FADHIL GRAPHY",
    "rdaftar": "TERIMAKASIH TELAH DAFTAR SEBAGAI TEMAN FADHILðŸ¤—",
    "limitt": "UNLIMITED",
    "memberLimit": 7,
    "groupLimit": 7
  }
```

---
## Install For PC/VPS/RDP

### Download

- Download libwebp & tutorial [here](https://developers.google.com/speed/webp/download)
- Download FFmpeg [here](https://ffmpeg.org/download.html) - Tutorial Installing [here](http://blog.gregzaal.com/how-to-install-ffmpeg-on-windows/)
- Download Wget & tutorial [here](http://gnuwin32.sourceforge.net/packages/wget.htm)
- Download tesseract-ocr [here](https://tesseract-ocr.github.io/tessdoc/Downloads.html) - Tutorial Installing [here](https://emop.tamu.edu/Installing-Tesseract-Windows8)
- Download NodeJS [here](https://nodejs.org/en/download/)
- Download Git [here](https://git-scm.com/downloads) - Tutorial Installing [here](https://phoenixnap.com/kb/how-to-install-git-windows)

### Install

```bash
> git clone https://github.com/FdhlGraphy/botwa-termux
> cd botwa-termux
> npm install
> npm i imgbb-uploader
> npm i got
```

### Starting Bot

```bash
> npm start
```

### Stopping Bot

```bash
> Ctrl + C
```


## Features

| NEW USER | YES
| :---------------------------------------------: | :-----------: |
|  Register Name And Age origin|✅|

|  CREATOR  |                                           YES |
| :---------------------------------------------: | :-----------: |
| Sticker Maker|✅|
| Sticker Gif Maker|✅|
| Convert Sticker To Image|✅|
| Convert Video To MP3|✅|
| Black Pink Logo Maker|✅|
| 3D Text Maker|✅|
| Quote Maker|✅|
| Water Maker|✅|
| Fire Text Maker
| Marvel Logo Maker|✅|
| Snow Write Maker|✅|
| Ninja Logo Maker|✅|
| Logo Wolf Maker|✅|
| And much more |✅|

| MEDIA | YES |
| :-----------------: | :-------: |
| Trend Twit|✅|
| YT Search|✅|
| Wattpad Search|✅|

| EDUCATION | YES |
| :-----------------: | :-------: |
| The Meaning Of The Name|✅|
| Text To Sticker|✅|
| Nulis Name/class/text|✅|
| Quotes|✅|

| ASK | YES |
| :-----------------: | :-------: |
| Apakah|✅|
| Kapankah|✅|
| Bisakah|✅|

| DOWNLOADER | YES |
| :-----------------: | :-------: |
| Pinterest Downloader|✅|

| MEME | YES |
| :-----------------: | :-------: |
| Meme|✅|
| Meme Indo|✅|

| GROUP | YES |
| :-----------------: | :-------: |
| Open Group|✅|
| Link Group|✅|
| info Group|✅|
| Close Group|✅|
| Promote Member|✅|
| Demote Member|✅|
| Hide Tag|✅|
| Tag All Members|✅|
| Add Member|✅|
| Kick Member|✅|
| Show List Admins|✅|
| Leave Group|✅|
| Show Owner Group|✅|
| welcome New Members|✅|
| Nsfw|✅|

| SOUND | YES |
| :-----------------: | :-------: |
| Text To Speach|✅|

| MUSIC | YES |
| :-----------------: | :-------: |
| Music Lyrics|✅|
| Chord Guitar|✅|

| ISLAM | YES |
| :-----------------: | :-------: |
| Qur'an|✅|
| Qur'an Surah 1,2,3 dll |✅|

| STALK | YES |
| :-----------------: | :-------: |
| Instagram Stalk|✅|
| Tiktok Stalk|✅|

| WIBU | YES |
| :-----------------: | :-------: |
| Neonime|✅|
| Pokemon|✅|
| Nekonime|✅|
| Naruto|✅|
| Loli|✅|
| Random Shota|✅|
| Random Waifu|✅|
| Random Anime|✅|
| And much more|✅|

| FUN | YES |
| :-----------------: | :-------: |
| Kucing|✅|
| Anjing|✅|
| Alay|✅|
| Glitch|✅|
| hilih|✅|
| Cek Ganteng|✅|
| Watak|✅|
| Random Hobby|✅|
| Pinterest [Optional] |✅|

| INFORMATION | YES |
| :-----------------: | :-------: |
| List Bahasa|✅|
| Information Weather|✅|
| KBBI|✅|
| Fakta|✅|
| Covid|✅|
| Gempa Terkini|✅|

| 18+ | YES |
| :-----------------: | :-------: |
| Random Hentai|✅|
| NSFW Neko|✅|

| OWNER | YES |
| :-----------------: | :-------: |
| Set pp bot|✅|
| Set Reply Chat|✅|
| add premium |✅|
| remove premium |✅|
| Set Prefix|✅|
| Block Member|✅|
| Broadcast|✅|
| Group Broadcast|✅|
| Clear All Chat|✅|

| PREMIUM MENU | YES |
| :-----------------: | :-------: |
| Youtube mp3 Download|✅|
| Youtube mp4 Download|✅|
| Joox|✅|
| Facebook Video Download|✅|
| Snack Video Download|✅|
| Play Mp3|✅|

 TENTANG BOT | YES |
| :-----------------: | :-------: |
| info|✅|
| ChatList|❌|


## Special Thanks To

* <a href="https://github.com/Fxc7"><img alt="GitHub" src="https://img.shields.io/badge/Farhan%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>
* <a href="https://github.com/NazwaS"><img alt="GitHub" src="https://img.shields.io/badge/NazwaS%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>
* <a href="https://github.com/FdhlGraphy"><img alt="GitHub" src="https://img.shields.io/badge/Fadhil%20Graphy%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>
* <a href="https://github.com/MhankBarBar"><img alt="GitHub" src="https://img.shields.io/badge/Mahankbarbar%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>
* <a href="https://github.com/affisjunianto"><img alt="GitHub" src="https://img.shields.io/badge/affisjunianto%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>





---
